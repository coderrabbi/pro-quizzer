import React from "react";

const Footer = () => {
  return (
    <div className="bg-pink-500 py-5">
      <p className="text-lg text-center font-semibold">
        © 2022,All Right Reserved By Coder Rabbi
      </p>
    </div>
  );
};

export default Footer;
